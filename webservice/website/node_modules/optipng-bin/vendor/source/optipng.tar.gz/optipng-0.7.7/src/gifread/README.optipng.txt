Name: gifread
Summary: A simple GIF reader
Author: Cosmin Truta
License: BSD-like; see gifread.h
