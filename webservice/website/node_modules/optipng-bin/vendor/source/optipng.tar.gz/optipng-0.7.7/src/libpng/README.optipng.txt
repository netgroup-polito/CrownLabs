Name: libpng
Summary: The PNG reference library
Authors: Glenn Randers-Pehrson et al.
Version: 1.6.34
License: the libpng license (zlib-like); see LICENSE
URL: http://libpng.org/

Modifications:
- Added pnglibconf.h.optipng to allow a leaner and meaner libpng build.
